import{r,g as t}from"./core-CAS-aVgU.js";var o=r();const e=t(o);export{e as R};
